import {Note} from './note';
import { Observable} from 'rxjs';

export class NoteStub {
    addNote(note : Note):Observable <Note>{
        if(note.title === 'invalid' && note.text === 'invalid'){
            return Observable.create({message:'youe value are invalid'});
        }
        return Observable.create(note);

    }
}
