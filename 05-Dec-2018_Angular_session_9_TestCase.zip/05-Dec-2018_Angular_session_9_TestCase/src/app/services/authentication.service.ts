import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private httpClient : HttpClient) { }
  authenticateUser(data){
    return this.httpClient.post('http://localhost:3000/auth/v1',data);
  }

  setBearer(token){
    localStorage.setItem('bearerToken',token);
  }
  getBearerToken(){
    return localStorage.getItem('bearerToken');
  }

  isUserAuthencated(token):Promise<boolean>{
    console.log("Token from isUserAuthencated");
    
    //return null;
   return this.httpClient.post('http://localhost:3000/auth/v1/isAuthenticated',{},{
      headers : new HttpHeaders()
      .set('Authorization',`Bearer ${token}`)
    })
    .pipe(map((res) => res['isAuthenticated']))
    .toPromise();
  }
}
