import { Injectable } from '@angular/core';
// import http module in our angular application 
import { HttpClient,HttpHeaders } from '@angular/common/http';
// To get the data from get request for httpClient
import { Observable, BehaviorSubject } from 'rxjs';
import { AuthenticationService} from './authentication.service';
import {tap} from 'rxjs/operators';

import { Note } from '../note';
//import { TouchSequence } from 'selenium-webdriver';

@Injectable({
  providedIn: 'root'
})

export class NoteService {

  notes : Array<Note>;
  notesSubject : BehaviorSubject<Array<Note>>;
  token : any;

// Inject Http Client in the application
  constructor(private httpClient : HttpClient, 
              private authService : AuthenticationService) {
    this.notes = [];
    this.notesSubject = new BehaviorSubject(this.notes);
    this.fetchNotesFromServer();            
              }
  
  // Method to get thee notes
fetchNotesFromServer(){
  this.token = this.authService.getBearerToken();
  return this.httpClient.get<Array<Note>>('http://localhost:3000/api/v1/notes',{
       headers : new HttpHeaders().set('Authorization',`Bearer ${this.token}`) 
     }).subscribe(notes  => {
       this.notes = notes
       this.notesSubject.next(this.notes);
     });
}

  getNotes():Observable<Note[]>{
    // get to fetch the result
    // the return type is observable
    return this.notesSubject 
     
   }
   addNote(note:Note):Observable<Note>{
     return this.httpClient.post<Note>('http://localhost:3000/api/v1/notes',note,{
      headers : new HttpHeaders().set('Authorization',`Bearer ${this.authService.getBearerToken()}`) 
    });
   }
  getNoteById(noteId) : Note{
    console.log('inside getNoteById ');
    
    const note = this.notes.find(note => note.id ===noteId);
    return Object.assign({},note);
  }

 editNote( note): Observable<Note>{
   return this.httpClient.put<Note>(`http://localhost:3000/api/v1/notes/${note.id}`,note,{
     headers : new HttpHeaders().set('Authorization',`Bearer ${this.authService.getBearerToken()}`)
   }).pipe(tap(editedNote => {
     const existingNote = this.notes.find(noteValue => noteValue.id === editedNote.id);
      Object.assign(existingNote,editedNote);
     this.notesSubject.next(this.notes)
  }));
}
}
/* Case study
case 1: - 
  server is giving us an api like :-
    get:-  http://localhost:3000/api/v1/notes/:id

case 2:-
  api is 
    get :- http://localhost:3000/api/v1/notes
  you need to create an array and get one note from the array.

*/