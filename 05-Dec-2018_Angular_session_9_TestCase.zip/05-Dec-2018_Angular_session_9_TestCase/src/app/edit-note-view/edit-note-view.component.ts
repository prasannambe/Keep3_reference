import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { NoteService } from '../services/note.service';
import { Note } from '../note';

@Component({
  selector: 'app-edit-note-view',
  templateUrl: './edit-note-view.component.html',
  styleUrls: ['./edit-note-view.component.css']
})
export class EditNoteViewComponent implements OnInit {

  note : Note;

  constructor(private matDialogRef : MatDialogRef<EditNoteViewComponent>,
                @Inject(MAT_DIALOG_DATA) public data : any,
                private noteService : NoteService) {
                  
                  //console.log(this.data);
              //  this.note = this.noteService.getNoteById(this.data.note);
                  
                  
                 }

  ngOnInit() {
     //console.log("inside on init ",this.data);
    this.note = this.noteService.getNoteById(this.data.note);
   }
   editNote(){
     this.noteService.editNote(this.note).subscribe(editNote => {
       this.matDialogRef.close();
     })
   }
  }
