import { Component, OnInit } from '@angular/core';
import { Note } from  '../note';
import { NoteService } from '../services/note.service';

@Component({
  selector: 'app-note-view',
  templateUrl: './note-view.component.html',
  styleUrls: ['./note-view.component.css']
})
export class NoteViewComponent implements OnInit {
  notes:Array<Note>;
  errorMessage : string;
  constructor(private noteService : NoteService) {
    this.notes = [];
   }

  ngOnInit() {
    this.noteService.getNotes().subscribe(
      notesResponseList => {
        this.notes = notesResponseList;  
      },
      error => {
        this.errorMessage = 'Some internal Error'
      }
    );
  }

}
