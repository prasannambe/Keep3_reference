import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = new FormControl('',[ Validators.required ]);
  password = new FormControl('', [ Validators.required] );
  public bearerToken :any ;
  constructor(private _authService : AuthenticationService ,
              private routerService : RouterService) { }


  ngOnInit() {
  }
  loginSubmit(){
    this._authService.authenticateUser({"username" : this.username.value,"password" : this.password.value})
    .subscribe(res => {
      console.log(res['token']);
      this.bearerToken = res['token'];
      this._authService.setBearer(this.bearerToken);
      this.routerService.routeToDashboard()
    },
    err => {
      console.log(err);
      
    })
    //console.log(this.username.value,this.password.value);
    
  }
  get_User_Error_Message(){
    return this.username.hasError('required')? 'You must Enter a user name':
            " ";
  }
  get_password_Error_Message(){
    return this.password.hasError('required') ? 'You must Enter the password':
            " ";
  }
}
