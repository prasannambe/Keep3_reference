import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NoteService } from '../services/note.service';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent implements OnInit {
  note: Note;
  errorMessage : string;
  constructor(private noteService : NoteService) {
    this.note = new Note();
   }
  
  ngOnInit() {
    this.note = new Note();
  }
  takeNote(){
    if(this.note.title !== ' ' && this.note.text !== " " ){
      //this.noteList.push(this.note);
      // to add the data into the database.
        this.noteService.addNote(this.note).subscribe(addedNote => {
          console.log('addNote',addedNote);
        },
        error =>{
          this.errorMessage = error.message;
        }
      );
      this.note = new Note();
    } else{
      this.errorMessage = "Title and text are required.";
    }
    }
}
