import {Note} from './note';
import { setDOM } from '@angular/platform-browser/src/dom/dom_adapter';

// Test Suite(collection of test cases)
describe('My Test Suit',() => {
    // to perform a task befor the test cases executed.
    beforeEach(() => {
        console.log('Before Each test case');
    })
    // test cases
    it('my first test case',() => {
        let first_note = new Note();
        first_note.title = 'test title-1';
        first_note.text = 'test text -1"';

        let first_note_e = new Note();
        first_note_e.title = 'test ';
        first_note_e.text = 'test text -1"';
        
        let second_note = new Note();
        second_note.title = 'test title-1';
        second_note.text = 'test text -1"';

        expect(first_note).toEqual(first_note_e);

        
        
    })
    it('my second test case',() => {
        console.log('---------Hello testing Again --------');
        
    })
    // to perform after an action after the test cases
    afterEach(() => {
        console.log("After each test case");
        
    })
})