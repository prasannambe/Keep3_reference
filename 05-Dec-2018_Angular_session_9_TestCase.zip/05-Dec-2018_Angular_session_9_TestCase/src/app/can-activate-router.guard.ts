import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticationService } from './services/authentication.service';
import { RouterService } from './services/router.service';

@Injectable({
  providedIn: 'root'
})
export class CanActivateRouterGuard implements CanActivate {
  constructor(private authService : AuthenticationService,
              private router : RouterService){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    const booleanPromise = this.authService.isUserAuthencated(this.authService.getBearerToken());
      return booleanPromise.then((authenticated) => {
      if(!authenticated){
        this.router.routeToLogin();
      }
      return authenticated;
    });
    //return true;
  }

  

}
