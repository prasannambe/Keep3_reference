export class Note {
    id : number;
    title:string;
    text:string;
    constructor(){
        this.title = "";
        this.text = "";
    }
}
